#!/usr/bin/env python3
"""Structural validator for the generated output.csv (no hidden labels required)."""
import csv, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "dataset"
OUTPUT = ROOT / "output.csv"

def load(path):
    with path.open(newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))

def main():
    requests = load(DATA / "deletion_requests.csv")
    rows = load(OUTPUT)
    expected_header = ["case_id", "deletion_status", "steps_json"]
    if rows and list(rows[0]) != expected_header:
        raise SystemExit(f"FAIL: output header must be {expected_header}")
    if len(rows) != len(requests):
        raise SystemExit(f"FAIL: expected {len(requests)} rows, found {len(rows)}")
    req_ids = {r["case_id"] for r in requests}
    out_ids = [r["case_id"] for r in rows]
    if set(out_ids) != req_ids or len(set(out_ids)) != len(out_ids):
        raise SystemExit("FAIL: output case IDs do not exactly match input IDs")
    if out_ids != sorted(out_ids, key=lambda x: int(x.rsplit("_", 1)[-1])):
        raise SystemExit("FAIL: output is not sorted by numeric case ID")

    errors = []
    counts = {"COMPLETE": 0, "INCOMPLETE": 0, "NOT_APPLICABLE": 0}
    total_steps = 0
    for row in rows:
        cid = row["case_id"]
        status = row["deletion_status"]
        if status not in counts:
            errors.append(f"{cid}: invalid status {status!r}")
            continue
        counts[status] += 1
        try:
            steps = json.loads(row["steps_json"])
        except Exception as exc:
            errors.append(f"{cid}: invalid steps_json ({exc})")
            continue
        if not isinstance(steps, list):
            errors.append(f"{cid}: steps_json is not an array")
            continue
        total_steps += len(steps)
        if status == "NOT_APPLICABLE" and steps:
            errors.append(f"{cid}: NOT_APPLICABLE must have []")
        if [s.get("step_no") for s in steps] != list(range(1, len(steps) + 1)):
            errors.append(f"{cid}: step numbers are not consecutive")
        order = {"FINDING": 0, "REMEDIATION": 1, "VERIFICATION": 2}
        phases = [order.get(s.get("phase"), -1) for s in steps]
        if -1 in phases or phases != sorted(phases):
            errors.append(f"{cid}: invalid or unordered phases")
        for step in steps:
            if not all(k in step for k in ("step_no", "phase", "system_id", "resource_id", "operation", "state", "evidence_id")):
                errors.append(f"{cid}: step missing required fields")
            if status == "COMPLETE" and step.get("phase") == "VERIFICATION" and not step.get("evidence_id"):
                errors.append(f"{cid}: completed verification lacks evidence")
            if status == "INCOMPLETE" and step.get("phase") in ("REMEDIATION", "VERIFICATION") and step.get("evidence_id"):
                errors.append(f"{cid}: proposed/future step must have empty evidence_id")
    print(f"Rows: {len(rows)}")
    print(f"Status counts: {counts}")
    print(f"Total steps: {total_steps}")
    print(f"Structural errors: {len(errors)}")
    for e in errors[:50]: print("-", e)
    if errors: raise SystemExit(1)

if __name__ == "__main__": main()
