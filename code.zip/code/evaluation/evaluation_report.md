# Evaluation Report — Ghost Data Still Exists

## Run under evaluation

- Entry point: `python3 code/main.py`
- Full input: `dataset/deletion_requests.csv`
- Generated artifact: repository-root `output.csv`
- Runtime: deterministic Python rules and evidence parsing; no external model calls.

## Full-dataset structural metrics

The final full-dataset run produced 518 output rows for 518 requests, with the exact header `case_id,deletion_status,steps_json`, sorted by numeric case suffix. The status distribution is **38 COMPLETE, 479 INCOMPLETE, and 1 NOT_APPLICABLE**. The structural validator (`python3 code/evaluation/main.py`) reports 518 rows, 2,811 total steps, and zero structural errors: each JSON array parses, step numbers are consecutive, and phases are ordered FINDING → REMEDIATION → VERIFICATION.

Important limitation: **33 INCOMPLETE rows have an empty `steps_json` array** because the available evidence could not be safely linked to a concrete resource. The validator checks syntax and ordering, not completeness of a remediation plan, so these cases remain a known semantic defect and require further investigation. These checks are not a claim that hidden canonical answers have been matched. No hidden gold labels are available to this implementation.

## Public sample benchmark

The 32-row `sample_deletion_requests.csv` / `sample_output.csv` pair was run in an isolated copy of the repository. Results:

- Case-level deletion-status accuracy: **25/32 = 78.125%**.
- Exact `steps_json` array matches: **1/32**.
- The low exact-step match rate reflects gaps in resource-state reconstruction, snapshot absence interpretation, and ordering/selection of evidence-backed checks.

This benchmark result is a material limitation and should not be presented as production-ready accuracy.

## Additional evaluation cases created

1. **Explicit refusal / no deletion authorization** — request text says the customer still uses the account and asks not to delete or change anything. Expected: `NOT_APPLICABLE` and `[]`.
2. **Historical-email resolution** — the request email appears as an `old_value` in `user_audit_log.csv`; evidence refers to the same stable `user_id` under the newer email. Expected: both identifiers resolve to one subject and relevant records are considered.
3. **Active integration flow** — a matching `data_flow_*` resource is shown as active at or before `audit_at`. Expected: `REPORT_ACTIVE_DATA_FLOW`, then `DISABLE_DATA_FLOW`, then `VERIFY_DATA_FLOW_DISABLED`, with proposed remediation/future verification evidence IDs blank.
4. **PII-bearing account tombstone** — a deleted-account reference retains name/email/phone or email hash. Expected: `REPORT_EXPOSED_PII`, `REDACT_RECORD`, and `VERIFY_RECORD_REDACTED`, while retaining only the permitted stable user reference.
5. **Time-bound evidence** — a resource is present only in evidence captured after `audit_at`. Expected: later evidence must not be used to claim the state at the earlier audit time.

These cases are specification-driven checks; they are not represented as hidden-gold benchmark results.

## Failures found and improvements made

- Added numeric case sorting rather than lexicographic sorting.
- Added explicit handling for multilingual deletion-request text and explicit refusal language.
- Added resource linking through stable user IDs, current/historical emails, and identity-link activity.
- Added structured parsing for JSON snapshots, SQL tables, pipe-delimited handover rows, logs, and PDF text where available.
- Added checks that incomplete-case remediation and future-verification steps have empty evidence IDs, while completed verification steps cite evidence.
- Added tombstone, retained security record, active flow, and restore-risk branches.

Remaining failure modes:

- Some evidence snapshots are sparse; absence from a partial snapshot is not sufficient proof of deletion.
- Resource identity linkage can be ambiguous when an event log contains only a resource association but no state proof.
- OCR for screenshot evidence is intentionally skipped for runtime stability; screenshot-only facts may be missed.
- Current status/step precision remains below a submission-quality target, as the public sample metrics show.

## Recommended next improvements

1. Parse each SQL snapshot's topology and query-result semantics explicitly rather than treating every inserted row as an independent record.
2. Build a time-aware resource graph that separates identity linkage, existence evidence, and operation claims.
3. Add OCR and visual validation for screenshots, and extract PDF tables with a robust parser.
4. Create a golden test harness that compares status, fields, resource sets, and exact step ordering after each change.
