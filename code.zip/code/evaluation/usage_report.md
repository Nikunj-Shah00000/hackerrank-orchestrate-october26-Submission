# Model, Token, and Cost Usage Report

## Full-dataset run

- Input requests: 518
- Output rows: 518
- Model provider: None
- Model name: None — the solution is a deterministic local Python rules engine.
- External model/API calls: 0
- Input tokens: 0
- Output tokens: 0
- Total tokens: 0
- Average tokens per request: 0
- Estimated model/API cost: **$0.00 total** and **$0.00 per request**

## Accounting notes

The implementation uses local CSV parsing, JSON parsing, SQLite-compatible SQL snapshot parsing, text/log parsing, and optional `pdftotext` for PDFs. No generative model was invoked, so there are no provider-specific token counts or model charges to report. Local CPU time and storage costs are not included in model/API cost.
