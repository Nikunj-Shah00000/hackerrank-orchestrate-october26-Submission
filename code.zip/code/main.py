#!/usr/bin/env python3
"""Evidence-driven deletion audit for HackerRank Orchestrate."""
import csv, json, re, os, sqlite3, subprocess, tempfile
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "dataset"
OUT = ROOT / "output.csv"
def read_csv(name):
    with open(DATA/name, newline="", encoding="utf-8-sig") as f: return list(csv.DictReader(f))
def norm(s): return re.sub(r"\s+"," ",str(s or "").strip().lower())
def ts(s):
    try: return datetime.fromisoformat(str(s).replace("Z","+00:00"))
    except: return datetime.min.replace(tzinfo=timezone.utc)
def safejson(s):
    try: return json.loads(s)
    except: return None

requests=read_csv("deletion_requests.csv")
identities=read_csv("user_identities.csv")
audits=read_csv("user_audit_log.csv")
activities=read_csv("system_activity.csv")
manifest=read_csv("evidence_files.csv")

# Build a parsed, searchable evidence corpus. Each item is a record-like object or a text line.
evidence_items=[]
for mf in manifest:
    path=DATA/mf["file_path"]; fid=mf["file_id"]
    if not path.exists(): continue
    captured=ts(mf.get("captured_at"))
    ext=path.suffix.lower()
    try:
        if ext==".json":
            root_obj=json.loads(path.read_text(encoding="utf-8"))
            def walk(o, system="", collection="", snap_time=None, parent_key=""):
                known_systems={"account_service","identity_service","search_service","search_index_service","analytics_platform","support_platform","backup_service","integration_service","security_service","export_service","marketing_service","cache_service","email_service","notification_service"}
                if isinstance(o,dict):
                    system=o.get("data_store",system); collection=o.get("collection",collection)
                    snap_time=o.get("captured_at",o.get("observed_at",snap_time))
                    if parent_key in known_systems: system=parent_key
                    if o.get("resource_id"):
                        # Evidence availability is bounded by the manifest capture time. Do not
                        # let an export captured after audit_at leak its embedded historical timestamps.
                        item={"file_id":fid,"time":captured,"system":system or "unknown",
                              "resource_id":str(o.get("resource_id")),"category":str(o.get("data_category") or o.get("record_type") or collection or parent_key or ""),
                              "data":o,"text":json.dumps(o,ensure_ascii=False),"kind":"record"}
                        evidence_items.append(item)
                    for k,v in o.items():
                        if isinstance(v,(dict,list)):
                            next_collection = k if not system or k not in known_systems else collection
                            walk(v,system,next_collection,snap_time,k)
                elif isinstance(o,list):
                    for v in o: walk(v,system,collection,snap_time,parent_key)
            walk(root_obj)
            # Also preserve compact lines for event-like JSON with IDs but no resource_id.
            for obj in (root_obj if isinstance(root_obj,list) else []):
                pass
        elif ext==".sql":
            txt=path.read_text(encoding="utf-8",errors="ignore")
            db=sqlite3.connect(":memory:")
            try:
                db.executescript(txt)
                for table, in db.execute("select name from sqlite_master where type='table'"):
                    cols=[r[1] for r in db.execute(f'pragma table_info("{table}")')]
                    for row in db.execute(f'SELECT * FROM "{table}"'):
                        d=dict(zip(cols,row))
                        raw=d.get("record_json")
                        dat=safejson(raw) if raw else d
                        rid=str(d.get("resource_id") or (dat or {}).get("resource_id") or "")
                        sys=str(d.get("origin_system") or d.get("system_id") or "")
                        cat=str(d.get("collection_name") or d.get("data_category") or d.get("record_type") or table)
                        if isinstance(dat,dict): txtrec=json.dumps(dat,ensure_ascii=False)
                        else: txtrec=str(d)
                        if rid:
                            evidence_items.append({"file_id":fid,"time":captured,"system":sys or "unknown","resource_id":rid,"category":cat,"data":dat or d,"text":txtrec,"kind":"record"})
            except Exception: pass
            finally: db.close()
        else:
            if ext==".pdf":
                try: txt=subprocess.run(["pdftotext","-layout",str(path),"-"],capture_output=True,text=True,timeout=10).stdout
                except: txt=""
            elif ext==".png":
                # Screenshots are supplemented by structured snapshots and logs; skip OCR for deterministic runtime.
                txt=""
            else: txt=path.read_text(encoding="utf-8",errors="ignore")
            for line in txt.splitlines():
                if line.strip():
                    # Parse structured handover rows: timestamp | system | resource | category | state | subject.
                    parts=[x.strip() for x in line.split("|")]
                    pipe_system=pipe_rid=pipe_cat=""
                    if len(parts)>=5 and re.search(r"\d{4}-\d{2}-\d{2}T",parts[0]) and "_" in parts[1] and re.match(r"[A-Za-z]+_\d+",parts[2]):
                        pipe_system,pipe_rid,pipe_cat=parts[1],parts[2],parts[3]
                    # Extract key-value fields from log / report lines.
                    ridm=re.search(r'\b(resource_id|resource|record_id)\s*[=:]\s*["\']?([A-Za-z][A-Za-z0-9_-]*_\d+)',line,re.I)
                    if not ridm:
                        ridm=re.search(r'\|\s*([A-Za-z][A-Za-z0-9_-]*_\d+)\s*\|',line)
                    rid=(pipe_rid or (ridm.group(2) if ridm and len(ridm.groups())>1 else (ridm.group(1) if ridm else "")))
                    sm=re.search(r'\b(?:service|system|source_system|data_store)\s*[=:]\s*["\']?([A-Za-z][A-Za-z0-9_-]+)',line,re.I)
                    system=pipe_system or (sm.group(1) if sm else "")
                    cm=re.search(r'\b(?:record_type|category|collection|data_category)\s*[=:]\s*["\']?([A-Za-z][A-Za-z0-9_-]+)',line,re.I)
                    cat=pipe_cat or (cm.group(1) if cm else "")
                    if rid:
                        evidence_items.append({"file_id":fid,"time":captured,"system":system or "unknown","resource_id":rid,"category":cat,"data":{},"text":line,"kind":"line"})
                    # Keep all lines to resolve not-found checks and active risks.
                    evidence_items.append({"file_id":fid,"time":captured,"system":system or "unknown","resource_id":rid,"category":cat,"data":{},"text":line,"kind":"line"})
    except Exception:
        continue

# Activity is corroborating evidence, timestamped individually.
for a in activities:
    evidence_items.append({"file_id":a["activity_id"],"time":ts(a.get("event_time")),"system":a.get("target_system") or a.get("source_system") or "unknown",
        "resource_id":a.get("resource_id",""),"category":a.get("event_type",""),"data":a,"text":json.dumps(a,ensure_ascii=False),"kind":"activity"})

# Build an inverted evidence index so each request only examines evidence that mentions its identifiers.
email_index = {}
uid_index = {}
for ix, it in enumerate(evidence_items):
    txt = it.get("text", "")
    # Structured fields are also serialized into text above.
    for em in set(re.findall(r"[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}", txt, re.I)):
        email_index.setdefault(norm(em), set()).add(ix)
    for um in set(re.findall(r"\buser_\d+\b", txt, re.I)):
        uid_index.setdefault(norm(um), set()).add(ix)

# Index identifiers and account IDs for each request.
id_by_user={}
for u in identities:
    vals={u.get("user_id",""),u.get("name",""),u.get("email",""),u.get("phone",""),u.get("email_hash","")}
    id_by_user[u["user_id"]]=vals
for a in audits:
    vals=id_by_user.setdefault(a["user_id"],{a["user_id"]})
    vals.update([a.get("old_value",""),a.get("new_value","")])

# Some log lines use historical email variants; normalize email case.
def intent_is_deletion(req):
    t=norm(req.get("request_text",""))
    # Explicitly informational, cancellation, wrong-recipient, or refusal messages are not authorized deletion.
    non=[r"\bnot asking (?:you )?to delete\b",r"\bdo not delete\b",r"\bdon't delete\b",r"\bnot a deletion request\b",
         r"\bwrong person\b.*\bnot\b"]
    if any(re.search(p,t) for p in non): return False
    # Most inputs are direct requests; explicit verify-only phrasing is still a deletion audit if account deletion is asserted.
    if re.search(r"\b(delete|deletion|erase|erasure|remove|close|account|suppression|supprimer|suppression|eliminaci[oó]n|eliminar|borrar|exclus[aã]o|excluir|apagar|삭제|제거|消去|削除|依頼|exclusão)\b",t) or any(x in t for x in ["삭제","削除","完全な削除","永久删除"]):
        return True
    # Requests in other languages are the default in this deletion-request dataset unless explicitly negated above.
    return True

# Known category/system mapping, policy actions and allowed operation ordering.
def classify(system, category, text, data):
    s=norm(system).replace(" ","_"); c=norm(category).replace(" ","_")
    blob=norm(text+" "+json.dumps(data,ensure_ascii=False))
    if "tombstone" in c or "tombstone_" in blob or "deleted_customer_references" in blob or "account_tombstone" in c: return "TOMBSTONE"
    if "security" in s or "security_audit" in c or "audit_record_" in blob: return "RETAIN"
    if "backup" in s or "backup_archive" in c or "restore" in blob: return "BACKUP"
    if "data_flow" in c or "integration" in s or "sync" in blob or "replication" in blob: return "FLOW"
    if "analytics" in s or "analytics" in c: return "ANALYTICS"
    if "telemetry" in c: return "TELEMETRY"
    if "support_attachment" in c or "attachment" in c: return "ATTACHMENT"
    if "support" in s or "support_message" in c: return "SUPPORT"
    if "search" in s or "search_index" in c or "search_" in blob: return "DELETE"
    if "export" in s or "user_export" in c: return "DELETE"
    if "marketing" in s or "marketing_profile" in c: return "DELETE"
    if "email_delivery" in c: return "REDACT"
    if "cache" in c: return "DELETE"
    if "account" in s or "user_profile" in c or "profile" in c: return "DELETE"
    if "pii" in blob and "support" in blob: return "SUPPORT"
    return "DELETE"

# Find record-like items that are linked to this user by any known identifier.
def match_item(item, identifiers, user_id):
    txt=item.get("_norm")
    if txt is None:
        txt=norm(item.get("text","")); item["_norm"]=txt
    # Resource context must contain at least one exact identifier; email matching is case-insensitive.
    for v in identifiers:
        if not v or len(str(v).strip())<4: continue
        vv=norm(v)
        # Stable user IDs must match as complete tokens (user_26 must not match user_260).
        if re.fullmatch(r"user_\d+", vv):
            if re.search(r'(?<![A-Za-z0-9_])'+re.escape(vv)+r'(?![A-Za-z0-9_])',txt): return True
        elif vv in txt:
            return True
    # User ID matching is only accepted as a complete token in structured text.
    if user_id and re.search(r'(?<![A-Za-z0-9_])'+re.escape(user_id)+r'(?![A-Za-z0-9_])',txt): return True
    return False

def extract_state(item, kind):
    blob=norm(item.get("text","")+" "+json.dumps(item.get("data",{}),ensure_ascii=False))
    data=item.get("data",{})
    if kind=="RETAIN": return "PRESENT"
    if kind=="SUPPORT":
        if isinstance(data,dict):
            direct=[data.get(k) for k in ("name","full_name","requester_name","email","requester_email","phone","requester_phone","email_hash")]
            if any(v not in (None,"") for v in direct): return "PII"
            if data.get("customer_reference") not in (None,""): return "REDACTED"
        if "redacted" in blob or "redact" in blob: return "REDACTED"
    if kind=="TOMBSTONE":
        # only stable reference allowed; direct identifier values make it exposed PII.
        if isinstance(data,dict):
            fields=["name","full_name","email","phone","email_hash"]
            if any(data.get(k) not in (None,"") for k in fields): return "PII"
        if any(x in blob for x in ["identifiable","pii_present","name\": \"","email\": \""]): return "PII"
        return "REDACTED"
    if kind in ("ANALYTICS","TELEMETRY"):
        if isinstance(data,dict):
            if any(data.get(k) not in (None,"") for k in ["email","phone","email_hash","name","full_name"]): return "PII"
            if data.get("user_id") not in (None,""): return "PII"
        if any(x in blob for x in ["identifiable","email=","email:","phone=","email_hash"]): return "PII"
        return "ANONYMIZED"
    if kind=="FLOW":
        if isinstance(data,dict) and data.get("enabled") is False: return "DISABLED"
        if isinstance(data,dict) and data.get("enabled") is True: return "ACTIVE"
        if any(x in blob for x in ["disabled","inactive","stopped","paused"]): return "DISABLED"
        if any(x in blob for x in ["active","enabled","running","success"]): return "ACTIVE"
    if kind=="BACKUP":
        if isinstance(data,dict) and data.get("restore_allowed") is False: return "BLOCKED"
        if isinstance(data,dict) and data.get("restore_allowed") is True: return "ACTIVE"
        if any(x in blob for x in ["blocked","inaccessible","restore_blocked"]): return "BLOCKED"
        return "ACTIVE"
    if any(x in blob for x in ["not_found","not found","absent","deleted","no record","result=miss","result=\"miss\"","status_code\": 404","status_code: 404","http_status=404","rows=0"]): return "ABSENT"
    if "redacted" in blob or "redact" in blob: return "REDACTED"
    if any(x in blob for x in ["found","present","identifiable","result=hit","result=\"hit\""]): return "PRESENT"
    return "PRESENT"

def sys_normalize(item, kind):
    s=norm(item.get("system","unknown")).replace(" ","_")
    if "customer_data_primary" in s: return "unknown"
    if s in ("account","account_service"): return "account_service"
    if s in ("identity_service","identity"): return "identity_service"
    if s in ("search","search_service","search_index_service"): return "search_service"
    if s in ("support","support_platform"): return "support_platform"
    if s in ("analytics","analytics_platform"): return "analytics_platform"
    if s in ("backup","backup_service"): return "backup_service"
    if s in ("integration","integration_service"): return "integration_service"
    if s in ("security","security_service"): return "security_service"
    if s in ("export","export_service"): return "export_service"
    if s in ("marketing","marketing_service"): return "marketing_service"
    if s in ("cache","cache_service"): return "cache_service"
    if s in ("email","email_service","notification_service"): return "email_service"
    if kind=="TOMBSTONE" and s=="unknown": return "identity_service"
    if s=="unknown":
        cat=norm(item.get("category",""))
        for key,val in [("account","account_service"),("search","search_service"),("support","support_platform"),("analytics","analytics_platform"),("backup","backup_service"),("integration","integration_service"),("security","security_service"),("export","export_service"),("marketing","marketing_service"),("cache","cache_service")]:
            if key in cat: return val
    return s or "unknown"

def make_step(phase,system,resource,operation,state,evidence):
    return {"step_no":0,"phase":phase,"system_id":system or "unknown","resource_id":resource or "unknown","operation":operation,"state":state,"evidence_id":evidence or ""}

all_outputs=[]
for req in requests:
    case=req["case_id"]; email=req["email"]; audit_time=ts(req["audit_at"])
    if not intent_is_deletion(req):
        all_outputs.append({"case_id":case,"deletion_status":"NOT_APPLICABLE","steps_json":"[]"}); continue
    # Resolve current/historical identity using case-insensitive email and audit changes.
    user=None
    for u in identities:
        if norm(u.get("email"))==norm(email): user=u; break
    if user is None:
        for a in audits:
            if norm(a.get("old_value"))==norm(email) or norm(a.get("new_value"))==norm(email):
                user=next((x for x in identities if x["user_id"]==a["user_id"]),None); break
    uid=user["user_id"] if user else ""
    identifiers=set(id_by_user.get(uid,set())) if uid else {email}
    identifiers.add(email)
    identifiers={str(x) for x in identifiers if x and len(str(x).strip())>=4}
    # Gather evidence at audit time only, retaining record and status lines.
    candidate_ids=set()
    for val in identifiers:
        if "@" in val:
            candidate_ids.update(email_index.get(norm(val), set()))
    if uid:
        candidate_ids.update(uid_index.get(norm(uid), set()))
    # Rare phone/hash-only references: inspect records only if no email/user-id index found.
    if not candidate_ids:
        for ix,it in enumerate(evidence_items):
            if match_item(it,identifiers,uid): candidate_ids.add(ix)
    # Identity-link events help resolve a resource even when the resource itself omits direct identifiers.
    linked_resources=set()
    link_events=[]
    for ix in list(candidate_ids):
        it=evidence_items[ix]
        # Later evidence may help map an identifier to a resource, but its state is never used before audit_at.
        if it.get("resource_id") and it.get("kind")!="activity" and match_item(it,identifiers,uid):
            linked_resources.add(it["resource_id"])
        if it.get("kind")=="activity" and it["time"]<=audit_time and norm(it.get("data",{}).get("event_type"))=="link_resource_identity":
            if it.get("resource_id"):
                linked_resources.add(it["resource_id"]); link_events.append(it)
    if linked_resources:
        for ix,it in enumerate(evidence_items):
            if it.get("resource_id") in linked_resources:
                candidate_ids.add(ix)
    hits=[]
    for ix in candidate_ids:
        it=evidence_items[ix]
        if it["time"]>audit_time: continue
        if it.get("kind")=="activity":
            if norm(it.get("data",{}).get("event_type"))=="link_resource_identity": hits.append(it)
            continue
        if match_item(it,identifiers,uid) or it.get("resource_id") in linked_resources:
            if it.get("resource_id") or it.get("kind")=="record": hits.append(it)
    # Consolidate duplicate observations for same system/resource; keep latest state evidence.
    records={}
    for it in hits:
        if not it.get("resource_id"): continue
        kind=classify(it.get("system",""),it.get("category",""),it.get("text",""),it.get("data",{}))
        system=sys_normalize(it,kind); rid=it["resource_id"]
        state=extract_state(it,kind)
        key=(system,rid,kind)
        old=records.get(key)
        if old is None or it["time"]>=old["time"]:
            records[key]={"item":it,"kind":kind,"system":system,"resource":rid,"state":state,"time":it["time"]}
    # Build findings for records that violate policy, and preserve required records for verification.
    findings=[]; remediations=[]; verifications=[]
    for rec in records.values():
        kind,state,sysid,rid=rec["kind"],rec["state"],rec["system"],rec["resource"]
        ev=rec["item"]["file_id"]
        # classify current resource treatment
        if kind=="RETAIN":
            verifications.append((3,sysid,rid,"VERIFY_RECORD_PRESENT","PRESENT",ev))
        elif kind=="TOMBSTONE":
            if state=="PII":
                findings.append((2,sysid,rid,"REPORT_EXPOSED_PII","PRESENT",ev))
                remediations.append((4,sysid,rid,"REDACT_RECORD","REDACTED",""))
                verifications.append((4,sysid,rid,"VERIFY_RECORD_REDACTED","REDACTED",""))
            else: verifications.append((4,sysid,rid,"VERIFY_RECORD_REDACTED","REDACTED",ev))
        elif kind=="FLOW":
            if state=="ACTIVE":
                findings.append((3,sysid,rid,"REPORT_ACTIVE_DATA_FLOW","ACTIVE",ev))
                remediations.append((1,sysid,rid,"DISABLE_DATA_FLOW","DISABLED",""))
                verifications.append((5,sysid,rid,"VERIFY_DATA_FLOW_DISABLED","DISABLED",""))
            else: verifications.append((5,sysid,rid,"VERIFY_DATA_FLOW_DISABLED","DISABLED",ev))
        elif kind=="BACKUP":
            if state!="BLOCKED":
                findings.append((4,sysid,rid,"REPORT_RESTORE_RISK","ACTIVE",ev))
                remediations.append((2,sysid,rid,"BLOCK_RESTORE","BLOCKED",""))
                verifications.append((6,sysid,rid,"VERIFY_RESTORE_BLOCKED","BLOCKED",""))
            else: verifications.append((6,sysid,rid,"VERIFY_RESTORE_BLOCKED","BLOCKED",ev))
        elif kind in ("ANALYTICS","TELEMETRY"):
            if state=="PII":
                findings.append((2,sysid,rid,"REPORT_EXPOSED_PII","PRESENT",ev))
                op="ANONYMIZE_RECORD" if kind=="ANALYTICS" else "ANONYMIZE_RECORD"
                remediations.append((5,sysid,rid,op,"ANONYMIZED",""))
                verifications.append((4,sysid,rid,"VERIFY_RECORD_ANONYMIZED","ANONYMIZED",""))
            else: verifications.append((4,sysid,rid,"VERIFY_RECORD_ANONYMIZED","ANONYMIZED",ev))
        elif kind=="SUPPORT":
            if state=="PII" or state=="PRESENT":
                findings.append((2,sysid,rid,"REPORT_EXPOSED_PII","PRESENT",ev))
                remediations.append((4,sysid,rid,"REDACT_RECORD","REDACTED",""))
                verifications.append((3,sysid,rid,"VERIFY_RECORD_REDACTED","REDACTED",""))
        elif state=="ABSENT":
            verifications.append((1,sysid,rid,"VERIFY_RECORD_ABSENT","ABSENT",ev))
        elif state=="PRESENT" or state=="PII":
            findings.append((1,sysid,rid,"REPORT_REMAINING_RECORD","PRESENT",ev))
            remediations.append((3,sysid,rid,"DELETE_RECORD","ABSENT",""))
            verifications.append((1,sysid,rid,"VERIFY_RECORD_ABSENT","ABSENT",""))
    # Ensure account profile absence is represented by a matching NOT_FOUND observation if available.
    # Otherwise the audit cannot safely claim the profile is gone; remediation is proposed.
    account_recs=[r for r in records.values() if r["system"]=="account_service" and r["kind"]=="DELETE"]
    if not account_recs:
        # Search matching not-found line items, including account lookups.
        nf=[]
        for it in evidence_items:
            if it["time"]<=audit_time and it.get("kind")!="activity" and it.get("resource_id") and match_item(it,identifiers,uid):
                blob=norm(it.get("text",""))
                if "account" in norm(it.get("system","")+it.get("category","")+blob) and any(x in blob for x in ["not_found","not found","absent","deleted","result=miss"]):
                    nf.append(it)
        if nf:
            it=max(nf,key=lambda x:x["time"])
            rid=it["resource_id"]; sysid="account_service"; ev=it["file_id"]
            verifications.append((1,sysid,rid,"VERIFY_RECORD_ABSENT","ABSENT",ev))
    # For incomplete cases, future verification evidence_id must be empty. If findings exist, plan remediation and all verifications.
    incomplete=bool(findings or remediations)
    if incomplete:
        # Findings cite evidence; only use observed evidence. If generated without evidence, omit fabricated finding and use an actionable plan.
        findings=[x for x in findings if x[5]]
        # Sort operation order, then system and resource.
        findings.sort(key=lambda x:(x[0],x[1],x[2],x[3]))
        remediations.sort(key=lambda x:(x[0],x[1],x[2],x[3]))
        # Verification steps for incomplete requests are future checks and have empty evidence.
        verifications=[(x[0],x[1],x[2],x[3],x[4],"") for x in verifications]
        verifications.sort(key=lambda x:(x[0],x[1],x[2],x[3]))
        # Only include one canonical verification per resource/operation.
        steps0=[]
        for group in (findings,remediations,verifications):
            seen=set()
            for order,sysid,rid,op,state,ev in group:
                k=(sysid,rid,op)
                if k in seen: continue
                seen.add(k); phase="FINDING" if group is findings else ("REMEDIATION" if group is remediations else "VERIFICATION")
                steps0.append(make_step(phase,sysid,rid,op,state,ev))
        status="INCOMPLETE" if findings or remediations else "COMPLETE"
    else:
        # Complete only if evidence-backed verification is available; do not trust workflow status.
        verifications.sort(key=lambda x:(x[0],x[1],x[2],x[3]))
        steps0=[]; seen=set()
        for order,sysid,rid,op,state,ev in verifications:
            if not ev: continue
            k=(sysid,rid,op)
            if k in seen: continue
            seen.add(k); steps0.append(make_step("VERIFICATION",sysid,rid,op,state,ev))
        has_account_absence=any(st.get("system_id")=="account_service" and st.get("operation")=="VERIFY_RECORD_ABSENT" for st in steps0)
        status="COMPLETE" if steps0 and has_account_absence else "INCOMPLETE"
        if status=="INCOMPLETE":
            # A not-yet-complete case may only propose future checks; evidence is deliberately blank.
            for st in steps0: st["evidence_id"]=""
    for i,st in enumerate(steps0,1): st["step_no"]=i
    all_outputs.append({"case_id":case,"deletion_status":status,"steps_json":json.dumps(steps0,separators=(",",":"),ensure_ascii=False)})

with open(OUT,"w",newline="",encoding="utf-8") as f:
    w=csv.DictWriter(f,fieldnames=["case_id","deletion_status","steps_json"]); w.writeheader()
    for r in sorted(all_outputs,key=lambda x:int(x["case_id"].split("_")[-1]) if x["case_id"].split("_")[-1].isdigit() else x["case_id"]): w.writerow(r)
print(f"Wrote {len(all_outputs)} rows to {OUT}")
